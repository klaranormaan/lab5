<!doctype html>
<html>
	<head>
	<meta charset="UTF-8">
	<title>Behind the book</title>
		<link rel="stylesheet" type="text/css" href="CSS/main.css">
		<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
	</head>	
	<body>
		<?php include("header.php"); ?>
		<div id="columnContainer">
			<div id="leftColumn">
				<h2>
					PICTURE GALLERY
				</h2>
				<ul id="imgList">
					<?php
					/*Added a loop that iterates through the img folder, and adds each element into the img list*/
					$dir = new DirectoryIterator("uploadedFiles");
					foreach ($dir as $img) {
						if (!$img->isDot()) {//checks if a entry is a "." or ".." and will in that case not include it.
						  echo "<li><img src=\"uploadedFiles/" . $img->getFilename() . "\"></li>";
						}
					}
					?>
  				</ul>
  				<style>
					#imgList li {
						max-width: 50%;
						list-style: none;
					}
					#imgList img {
						max-width: 100%;
					}
				</style>
			</div>
			<aside id="rightColumn">
				<div id="asideBox">
					<h3>
						Bestsellers
					</h3>
					<ul>
						<li>
							<a href="#">Title 1</a>
							<p>
								Firstname Lastlastname
							</p>
						</li>
						<li>
							<a href="#">Title 2</a>
							<p>
								Firstname Lastlastname
							</p>
						</li>
						<li>
							<a href="#">Title 3</a>
							<p>
								Firstname Lastlastname
							</p>
						</li>
						<li>
							<a href="#">Title 4</a>
							<p>
								Firstname Lastlastname
							</p>
						</li>
						<li>
							<a href="#">Title 5</a>
							<p>
								Firstname Lastlastname
							</p>
						</li>
					</ul>
				</div>
				<div id="asideBox2">
					<h3>
						New releases
					</h3>
					<ul>
						<li>
							<a href="#">Title 1</a>
							<p>
								Firstname Lastlastname
							</p>
						</li>
						<li>
							<a href="#">Title 2</a>
							<p>
								Firstname Lastlastname
							</p>
						</li>
						<li>
							<a href="#">Title 3</a>
							<p>
								Firstname Lastlastname
							</p>
						</li>
						<li>
							<a href="#">Title 4</a>
							<p>
								Firstname Lastlastname
							</p>
						</li>
						<li>
							<a href="#">Title 5</a>
							<p>
								Firstname Lastlastname
							</p>
						</li>
					</ul>
				</div>
			</aside>	
		</div>		
		<?php include("footer.php"); ?>
	</body>
</html>