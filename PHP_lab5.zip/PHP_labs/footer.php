<!doctype html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Behind the book</title>
		<link rel="stylesheet" type="text/css" href="CSS/main.css">
		<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
	</head>
	<body>
		<footer>
			<!---
				<div id="footerPart1">
					<div id="iconContainer">
						<a href="#"><img src="images/fb_icon.png"></a>
						<a href="#"><img src="images/insta_icon.png"></a>
						<a href="#"><img src="images/twitter_icon.png"></a>
					</div>
					<nav id="bottomNav">
						<ul>
							<li>
								<a href="index.php"> Home </a> 
							</li>
							<li>
								<a href="about_us.php"> About Us </a>
							</li>
							<li>
								<a href="browse_books.php"> Browse Books </a>
							</li>
							<li>
								<a href="my_books.php"> My Books </a>
							</li>
							<li>
								<a href="contact.php"> Contact </a>
							</li>
						</ul>
					</nav>	
				</div>
				-->
			<div id="footerPart2">
				<p>
					Discover, share and reserve books through an adventure behind the books.
				</p>
				<p id="footerP2">
					&#169;Behind the book - All rights reserved - 2017
				</p>
			</div>
		</footer>
	</body>
</html>